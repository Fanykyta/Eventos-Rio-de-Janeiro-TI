function Face() {
  //  alert("Eu sou um alert!");
        window.open("https://www.facebook.com/fanny.nunes.56");
    }
function twitter() {
  //  alert("Eu sou um alert!");
     window.open("https://twitter.com/Fanykyta22");
    }
function zap() {
  //  alert("Eu sou um alert!");
    window.open("http://api.whatsapp.com/send?1=pt_BR&phone=5511986436553");
    }
function telegram() {
  //  alert("Eu sou um alert!");
    window.open("https://t.me/EventosTI_RJ");
    }
function instagram() {
  //  alert("Eu sou um alert!");
    window.open("https://www.instagram.com/fanny.game/?hl=pt-br");
    }

window.onload = function(){
				document.getElementById('#link').click();
			}